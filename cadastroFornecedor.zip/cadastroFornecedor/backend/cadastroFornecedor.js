document.addEventListener("DOMContentLoaded", function () {

    // Função para mostrar/ocultar campo CNPJ
    function toggleCnpjFieldVisibility(display) {
        const cnpjInput = document.getElementById("cnpjInput");
        cnpjInput.style.display = display;
    }

    // Função para mostrar/ocultar campo CPF
    function toggleCpfFieldVisibility(display) {
        const cpfInput = document.getElementById("cpfInput");
        cpfInput.style.display = display;
    }

    // Manipulador de evento para alterar a visibilidade do campo CNPJ
    document.getElementById("tipoCadastro").addEventListener("change", function() {
        const tipo = this.value;
        if (tipo === "pf") {
            toggleCnpjFieldVisibility("none");
        } else {
            toggleCnpjFieldVisibility("block");
        }
    });

    // Manipulador de evento para alterar a visibilidade do campo CPF
    document.getElementById("tipoCadastro").addEventListener("change", function() {
        const tipo = this.value;
        if (tipo === "pj") {
            toggleCpfFieldVisibility("none");
        } else {
            toggleCpfFieldVisibility("block");
        }
    });

    // Manipulador de evento para ocultar os campos CPF e CNPJ ao selecionar "Tipo de Cadastro"
    document.getElementById("tipoCadastro").addEventListener("change", function() {
        const tipo = this.value;
        if (tipo === "nda") {
            toggleCpfFieldVisibility("none");
            toggleCnpjFieldVisibility("none"); 
        }
    });

});
